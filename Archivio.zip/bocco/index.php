<!DOCTYPE html>
<html lang="it">
	<head>
		<meta charset="utf-8">
		<meta http-equiv="X-UA-Compatible" content="IE=edge">
		<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
		<!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->
		<!-- Template -->
		<link rel="shortcut icon" href="img/favicon.ico" type="image/x-icon">
		<link rel="icon" href="img/favicon.ico" type="image/x-icon">
		<link href='https://fonts.googleapis.com/css?family=Economica:700' rel='stylesheet' type='text/css'>
        <link href="assets/css/bootstrap.min.css" rel="stylesheet" type="text/css">
        <link href="assets/css/fonts.css" rel="stylesheet" type="text/css">
        <link href="assets/css/font-awesome.css" rel="stylesheet" type="text/css">
        <link href="assets/css/default.css" rel="stylesheet" type="text/css">
        <link href="assets/css/mobile.css" rel="stylesheet" type="text/css">
        <link rel="stylesheet" href="assets/css/bootstrap-datepicker.css" type="text/css">
		<!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
		<!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
		<!--[if lt IE 9]>
			<script src="assets/js/html5shiv.min.js"></script>
			<script src="assets/js/respond.min.js"></script>
		<!-->
    <title>Index</title>   
	</head>
	<body>
	<header class="fissa">
	<div class="row color">
	<div class="col-md-4">
	<img src="./assets/img/KDS-SRL-LOGO-web-Konsol-2017-300px.png" alt="logoKDS"
	class="img-responsive altezza">
	</div>
	<div class="col-md-8">
	<img src="./assets/img/LOGO-COWO849_retina-WHITE.png" align="right" class="img-responsive altezza">
	</div>
		<div class="col-md-12">
	<h1 align="center">Sistema di prenotazione uffici</h1>
    </div>
	</div>
	</header>
	<br>
	<div class="row margineSuperiore">
	<div class="col-md-6">
	<h3>- Sala corsi (35 persone) &nbsp; &nbsp; &nbsp;<a href="./SalaCorsi.php"><input class="bottone" type="button" value="Info"></a></h3> 
	<br>
	<h3>- Sala DoWhile (6/8 persone) &nbsp; &nbsp; &nbsp;<a href="./SalaDoWhile.php"><input type="button" class="bottone" value="Info"></a></h3>
	<br>
	<h3>- Ufficio UnlessEnd (3 persone) &nbsp; &nbsp; &nbsp;<a href="./UfficioUnlessEnd.php"><input class="bottone" type="button" value="Info"></a></h3>
	<br>
	<h3>- Ufficio SwitchCase (3 persone) &nbsp; &nbsp; &nbsp;<a href="./UfficioSwitchCase.php"><input class="bottone" type="button" value="Info"></a></h3>
	<br>
	<h3>- Ufficio PerformUntil (2 persone) &nbsp; &nbsp; &nbsp;<a href="./UfficioPerformUntil.php"><input class="bottone" type="button" value="Info"></a></h3>
	<br>
	<h3>- Ufficio IfElse (2 persone) &nbsp; &nbsp; &nbsp;<a href="./UfficioIfElse.php"><input class="bottone" type="button" value="Info"></a></h3>
	<br>
	<h3>- Ufficio BeginEnd (1 persona) &nbsp; &nbsp; &nbsp;<a href="./UfficioBeginEnd.php"><input class="bottone" type="button" value="Info"></a></h3>
	<br>
	<h3>- Ufficio ForEach (1 persona) &nbsp; &nbsp; &nbsp;<a href="./UfficioForEach.php"><input class="bottone" type="button" value="Info"></a></h3>
	</div>
	<div class="col-md-6">
    <h2>Servizi compresi:</h2>
	<h4>
	-Rete wifi
	<br>
	-Rete telefonica
	<br>
	-Arredo (scrivanie,cassettiere,sedie)
	<br>
	-Pulizia uffici
	<br>
	-Servizio di vigilanza
	<br>
	-Aria condizionata
	<br>
    -Servizio di domiciliazione
    <br>
    -Fax e stampante
    <br>
    -Assistenza tecnica
    <br>
    -Servizio di segreteria
    <br>
    -Assicurazione immobili
	</h4>
	<br>
    <img src="./assets/img/ufficio6.jpg" width="550" height="400">
	</div>
        </div>
    
        <script src="assets/js/jquery.min.js" type="text/javascript"></script>
        <script src="assets/js/bootstrap.min.js" type="text/javascript"></script>
        <script src="assets/js/bootstrap-datepicker.min.js" type="text/javascript"></script>
        <script src="assets/js/bootstrap-datepicker.it.min.js" type="text/javascript"></script>
        <script src="assets/js/main.js" type="text/javascript"></script>
        
    </body>
</html>