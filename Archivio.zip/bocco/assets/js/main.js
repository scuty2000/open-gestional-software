$('.mezzagiornata').click(function (){
    $('#orario').css('display','block');
    $('#orario1').css('display','none')
});

$( function() {
            $( "#datepicker" ).datepicker({
            language: 'it'
            });
          } );

$('.1ora').click(function (){
    $('#orario1').css('display','block');
    $('#orario').css('display','none');
});

$('.1giorno').click(function (){
    $('#orario1').css('display','none');
    $('#orario').css('display','none');
});

