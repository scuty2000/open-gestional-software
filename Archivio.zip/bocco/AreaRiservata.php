<!DOCTYPE html>
<html lang="it">
	<head>
		<meta charset="utf-8">
		<meta http-equiv="X-UA-Compatible" content="IE=edge">
		<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
		<!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->
		<!-- Template -->
		<link rel="shortcut icon" href="img/favicon.ico" type="image/x-icon">
		<link rel="icon" href="img/favicon.ico" type="image/x-icon">
		<link href='https://fonts.googleapis.com/css?family=Economica:700' rel='stylesheet' type='text/css'>
        <link href="assets/css/bootstrap.min.css" rel="stylesheet" type="text/css">
        <link href="assets/css/fonts.css" rel="stylesheet" type="text/css">
        <link href="assets/css/font-awesome.css" rel="stylesheet" type="text/css">
        <link href="assets/css/default.css" rel="stylesheet" type="text/css">
        <link href="assets/css/mobile.css" rel="stylesheet" type="text/css">
        <link rel="stylesheet" href="assets/css/bootstrap-datepicker.css" type="text/css">
		<!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
		<!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
		<!--[if lt IE 9]>
			<script src="assets/js/html5shiv.min.js"></script>
			<script src="assets/js/respond.min.js"></script>
		<!-->
    <title>Area riservata</title>   
	</head>
	<body>
	<header class="fissa">
	<div class="row color">
	<div class="col-md-4">
	<img src="./assets/img/KDS-SRL-LOGO-web-Konsol-2017-300px.png" alt="logoKDS"
	class="img-responsive altezza">
	</div>
	<div class="col-md-8">
	<img src="./assets/img/LOGO-COWO849_retina-WHITE.png" align="right" class="img-responsive altezza">
	</div>
		<div class="col-md-12">
	<h1 align="center">Area riservata</h1>
    </div>
	</div>
	</header>
	<br>
	<div class="row margineSuperiore">
	<div class="col-md-12">
        <br>
        <form name="f1" action="gestione.php" method="POST">
<table class="accesso" border="0" align="center">
<tr>
<td>
    <h2><font color="white">Nome Utente</font></h2>
</td> 
<td>
    <input type="text" name="utente">
</td>
</tr>
<tr>
<td>
    <h2><font color="white">Password</font></h2>
</td> 
<td>
    <input type="password" name="pass">
</td>
</tr>
<tr>
    <td colspan="2" align="center">
    
        <input type="submit" class="bottone" name="invia" value="conferma">
    </td>
</tr>
</table>
        </form>
	</div>
        </div>
    
        <script src="assets/js/jquery.min.js" type="text/javascript"></script>
        <script src="assets/js/bootstrap.min.js" type="text/javascript"></script>
        <script src="assets/js/bootstrap-datepicker.min.js" type="text/javascript"></script>
        <script src="assets/js/bootstrap-datepicker.it.min.js" type="text/javascript"></script>
        <script src="assets/js/main.js" type="text/javascript"></script>
        
    </body>
</html>
