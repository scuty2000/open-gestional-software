<?php
/**
 *
 * File con query per PDO
 */

/* Inserisci parametri per il collegamento al DB e l'istanza della connessione'*/

include('connessione.php');

/* SELECT */
$queryFiliale = "SELECT id_utenti, id_filiale_fk FROM utenti WHERE id_utenti = :utenti";
        $filiale = $connessione->prepare($queryFiliale);
        /* con il metodo BINDPARAM associo il parametro al valore della variabile per inserirlo nella query*/
        $filiale->bindParam(':utenti', $id_utente);
        
        /*eseguo la query*/
        $filiale->execute();

        /* Recupero dei dati */

        while($filialeRisultato = $filiale->fetch(PDO::FETCH_ASSOC)) {
            $idFiliale = $filialeRisultato['id_filiale_fk'];
        }
        
        /* chiudo il cursore e libero la memoria dalla connessione */
         $filiale->closeCursor();
         $connessione = null;

/* INSERT */
$queryFiliale = "INSERT INTO ticket_master (titolo, id_stato_ticket_fk, id_societa_fk, id_filiale_fk, id_utente_fk, id_priorita_fk, data_apertura) VALUE (:titolo, :stato, :societa, :filiale, :utente, :priorita, :data )";
        $filiale = $connessione->prepare($queryFiliale);
          /* con il metodo BINDPARAM associo il parametro al valore della variabile per inserirlo nella query*/
        $filiale->bindParam(':utenti', $id_utente);
        $filiale->bindParam(':titolo', $titolo);
        
        /*eseguo la query*/
        $filiale->execute();

 /* chiudo il cursore e libero la memoria dalla connessione */
         $filiale->closeCursor();
         $connessione = null;


/* UPDATE*/

$query = $connessione->prepare('UPDATE profili SET descr = :descrizione WHERE id_profili = :id');
    
     /* con il metodo BINDPARAM associo il parametro al valore della variabile per inserirlo nella query*/
    $query->bindParam(':descrizione', $_POST['descr']);
    $query->bindParam(':id', $_POST['id']);

    /* eseguo la query */
    $query->execute();

     /* chiudo il cursore e libero la memoria dalla connessione */
    $query->closeCursor();
    $connessione = null;

 ?>