<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8">
		<meta http-equiv="X-UA-Compatible" content="IE=edge">
		<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
		<!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->
		<!-- Template -->
		<link rel="shortcut icon" href="img/favicon.ico" type="image/x-icon">
		<link rel="icon" href="img/favicon.ico" type="image/x-icon">
		<link href='https://fonts.googleapis.com/css?family=Economica:700' rel='stylesheet' type='text/css'>
        <link href="assets/css/bootstrap.min.css" rel="stylesheet" type="text/css">
        <link href="assets/css/fonts.css" rel="stylesheet" type="text/css">
        <link href="assets/css/font-awesome.css" rel="stylesheet" type="text/css">
        <link href="assets/css/default.css" rel="stylesheet" type="text/css">
        <link href="assets/css/mobile.css" rel="stylesheet" type="text/css">
  <title>Gestione</title>
</head>
<body>
<header class="fissa">
	<div class="row color">
	<div class="col-md-4">
	<img src="./assets/img/KDS-SRL-LOGO-web-Konsol-2017-300px.png" alt="logoKDS"
	class="img-responsive altezza">
	</div>
	<div class="col-md-8">
	<img src="./assets/img/LOGO-COWO849_retina-WHITE.png" align="right" class="img-responsive altezza">
	</div>
		<div class="col-md-12">
	<h1 align="center">Gestione</h1>
    </div>
	</div>
	</header>
    <br>
    <h1>CIAOCIAOICAOICOA</h1>
    <?php 
        $userLogin= $_POST['utente'];
        $passLogin= hash('sha256', $_POST['pass']);
    include('connessione.php');
        $query = "SELECT * FROM `utente` WHERE `user` LIKE :utente AND `password` LIKE :password";
        $login = $connessione->prepare($query);
        $login->bindParam(':utente', $userLogin);
        $login->bindParam(':password', $passLogin);
        $login->execute();
        $riga = $login->rowCount();
    
    if($riga>=1){
        
        echo "<p>Accesso Consentito</p>";
        
    } else {
        
        echo '<script> window.location.replace("AreaRiservata.php"); </script>';
    }
    ?>
    </body>
</html>
