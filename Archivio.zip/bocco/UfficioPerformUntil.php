<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8">
		<meta http-equiv="X-UA-Compatible" content="IE=edge">
		<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
		<!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->
		<!-- Template -->
		<link rel="shortcut icon" href="img/favicon.ico" type="image/x-icon">
		<link rel="icon" href="img/favicon.ico" type="image/x-icon">
		<link href='https://fonts.googleapis.com/css?family=Economica:700' rel='stylesheet' type='text/css'>
        <link href="assets/css/bootstrap.min.css" rel="stylesheet" type="text/css">
        <link href="assets/css/fonts.css" rel="stylesheet" type="text/css">
        <link href="assets/css/font-awesome.css" rel="stylesheet" type="text/css">
        <link href="assets/css/default.css" rel="stylesheet" type="text/css">
        <link href="assets/css/mobile.css" rel="stylesheet" type="text/css">
        <link rel="stylesheet" href="assets/css/bootstrap-datepicker.css" type="text/css">
  <title>Ufficio PerformUntil</title>
</head>
<body>
<header class="fissa">
	<div class="row color">
	<div class="col-md-4">
	<a href="./index.php"><img src="./assets/img/KDS-SRL-LOGO-web-Konsol-2017-300px.png" alt="logoKDS"
                               class="img-responsive altezza"></a>
	</div>
	<div class="col-md-8">
	<img src="./assets/img/LOGO-COWO849_retina-WHITE.png" align="right" class="img-responsive altezza">
	</div>
		<div class="col-md-12">
	<h1 align="center">Ufficio PerformUntill</h1>
    </div>
	</div>
	</header>
<br>
<div class="row margineSuperiore">
<div class="col-md-5">

    <h3 class="margine"><font color="white" style="font-family:System">Metratura:</font></h3>
    <h4 class="margine"><font color="white" style="font-family:System">10,56 m²</font></h4>
    <h3 class="margine"><font color="white" style="font-family:System">Prezzi:</font></h3>
    <h4 class="margine"><font color="white" style="font-family:System">mezza giornata € <?php
        echo "00";
        ?></font></h4>
    <h4 class="margine"><font color="white" style="font-family:System">1 giornata € <?php
        echo "00";
        ?></font></h4>
    <h4 class="margine"><font color="white" style="font-family:System">1 mese € <?php
        echo "00";
        ?></font></h4>
    <br>
    <img class="ruotata" style="margin-left: 50px"class="ruotata" src="./assets/img/performuntil.JPG" width="425" height="450">
</div>
<div class="col-md-1">
    <img src="./assets/img/Immagine.png" height="720" width="800">
</div>
<div class="col-md-6">
<form name="f1" method="get" action="prendi.php">
    <h3>Nome</h3><input class="dati" name="Nome" type="text">
    <h3>Cognome</h3><input class="dati" name="Cognome" type="text">
    <h3>E-mail</h3><input class="dati" name="Mail" type="text">
    <h3>Numero di telefono</h3><input name="Telefono" class="dati" type="text">
    <h3>Data inizio</h3><input type="text" id="datepicker">
<div class="container">
        <div class="radio">
      <label><input type="radio" name="durata" value="mezzagiornata" class="mezzagiornata">Mezza Giornata</label>
        </div>
    <div id="orario"><label><input type="radio" name="orario" value="mattina">&nbsp;&nbsp;9:00/13:00</label>
    <label><input type="radio" name="orario" value="pomeriggio">&nbsp;&nbsp;14:00/18:00</label></div>
            <div class="radio">
    <label><input type="radio" name="durata" value="1giorno" class="1giorno" >1 Giorno</label>
    </div>
    <div class="radio">
    <label><input type="radio" name="durata" value="1mese" class="1mese" >1 Mese</label>
    </div>
</div>
<input align="center" class="bottone" type="button" value="Invia">
<input type="text" disabled="true" class="sbagliato" name="errore">
    <input type="text" disabled="true" class="giusto" name="corretto">
</form>
</div>
</div>
    <script src="assets/js/jquery.min.js" type="text/javascript"></script>
        <script src="assets/js/bootstrap.min.js" type="text/javascript"></script>
        <script src="assets/js/bootstrap-datepicker.min.js" type="text/javascript"></script>
        <script src="assets/js/bootstrap-datepicker.it.min.js" type="text/javascript"></script>
        <script src="assets/js/main.js" type="text/javascript"></script>
</body>
</html>