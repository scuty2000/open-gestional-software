<?php
/**
 *
 * File per l'apertura della connessione con PDO
 */

$host = "localhost"; $user = "root"; $pwd =""; $db = "cowo";
 
 $dsn = 'mysql:host='.$host.';dbname='.$db;
 
 // blocco try per il lancio dell'istruzione
try {
  // connessione tramite creazione di un oggetto PDO
  $connessione = new PDO($dsn, $user , $pwd );
}
 
// blocco catch per la gestione delle eccezioni
catch(PDOException $e) {
 
  // notifica in caso di errorre
  echo 'Attenzione: '.$e->getMessage();
}
 ?>