<!DOCTYPE html>
<html>
<head>
<title>Prenotazione</title>

<?php
    
	$stanza=$_GET["stanza"];
    
    $id_stanza = $stanza;
    
    if ($stanza == 1) {
        
        $stanza = "{Beginend} (algol)";
        
    }
    
    if ($stanza == 2) {
        
        $stanza = "{forEach} (c#)";
        
    }
    
    if ($stanza == 3) {
        
        $stanza = "{ifElse} (c#)";
        
    }
    
    if ($stanza == 4) {
        
        $stanza = "{performuntil} (cobol)";
        
    }
    
    if ($stanza == 5) {
        
        $stanza = "{SwitchCase} (c#)";
        
    }
    
    if ($stanza == 6) {
        
        $stanza = "{unlessend} (ruby)";
        
    }
    
    if ($stanza == 7) {
        
        $stanza = "{DoWhile} (c#)";
        
    }
    
    if ($stanza == 8) {
        
        $stanza = "Sala Corsi";
        
    }
    
?>

<!-- table layout -->
<link rel="stylesheet" href="assets/table.css">

</head>
<body>
<center>
<form name="f1" action="addPren.php" method="POST">
<section>
<div class="tbl-header">
<table>
<tr align="center">
	<th>
    	<h1>Modulo richiesta prenotazione</h1>
    </th>
</tr>
</table>
</div>
<div class="tbl-content">
<table>
<tr>
	<td>
    	Nome:
    </td>
    <td>
       <input type="text" name="nome" placeholder="Nome" required/>
    </td>
</tr>
<tr>
    <td>
       Cognome:
    </td>
    <td>
    	<input type="text" name="cognome" placeholder="Cognome" required/>
    </td>
</tr>
<tr>
    <td>
      Cellulare:
    </td>
    <td>
    	<input type="text" name="cellulare" placeholder="Telefono" required/>
    </td>
</tr>
<tr>
    <td>
     Indirizzo e-mail:
    </td>
    <td>
    	<input type="email" name="email" placeholder="Indirizzo e-mail" required/>
    </td>
</tr>
<tr>
    <td>
     Ufficio da prenotare:
    </td>
    <td>
    	<input type="text" name="ufficio" value="<?php echo $stanza; ?>"/>
    </td>
    <td>
    <input type="text" name="id_stanza" value="<?php echo $id_stanza; ?>"/>
    </td>
</tr>
<tr>
    <td>
     Data inizio prenotazione:
    </td>
    <td>
    	<input type="text" name="dataStart" placeholder="gg/mm/aaaa"/>
    </td>
</tr>
<tr>
    <td>
     Data fine prenotazione:
    </td>
   	<td>
    	<input type="text" name="dataEnd" placeholder="gg/mm/aaaa"/>
    </td>
</tr>
</table>
</div>
<br>
<input type="submit" value="Prenota"/>
</section>
</form>
</center>

</body>
<footer>
</footer>
