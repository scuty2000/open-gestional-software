<?php

echo $_POST["nome"];
echo "\n";
echo $_POST["cognome"];
echo "\n";
echo $_POST["cellulare"];
echo "\n";
echo $_POST["e-mail"];
echo "\n";
echo $_POST["ufficio"];
echo "\n";
echo $_POST["dataStart"];
echo "\n";
echo $_POST["dataEnd"];

?>