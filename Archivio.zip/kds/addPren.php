<?php

include('include/connessione.php');
    
$query = "INSERT INTO pren_future (stanza_prenotata, data_iniziale, data_finale, nome, cognome, email, cellulare, accettata) VALUE (:stanza, :dataStart, :dataEnd, :nome, :cognome, :email, :cellulare, 0 )";
$prenQuery = $connessione->prepare($query);
    
$prenQuery->bindParam(':nome', $_POST['nome']);
$prenQuery->bindParam(':email', $_POST['email']);
$prenQuery->bindParam(':stanza', $_POST['id_stanza']);
$prenQuery->bindParam(':cognome', $_POST['cognome']);
$prenQuery->bindParam(':dataEnd', $_POST['dataEnd']);
$prenQuery->bindParam(':cellulare', $_POST['cellulare']);
$prenQuery->bindParam(':dataStart', $_POST['dataStart']);
    
$prenQuery->execute();
    
$prenQuery->closeCursor();
$connessione = null;
    
?>
<!DOCTYPE html>
<html>
<head>
<title>Prenotazione</title>

<!-- table layout -->
<link rel="stylesheet" href="assets/table.css">

</head>
<body>
<center>
<section>
<div class="tbl-header">
<table>
<tr align="center">
<th>
<h1>Prenotazione Effettuata</h1>
</th>
</tr>
</table>
</div>
<div class="tbl-content">
<table>
<tr>
<td>
<h1> A breve sarai ricontattato tramite e-mail per avere conferma sulla prenotazione. Grazie! </h1>
</td>
</tr>
</table>
</div>
<br>
</section>
</center>

</body>
<footer>
</footer>

