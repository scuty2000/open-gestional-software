<?php

include('include/connessione.php');
    
$source = $_GET['source'];

    if ($source == "prenotazione"){

        $query = $connessione->prepare('UPDATE disp_uffici SET data_inizio_prenotazione = :startDate, data_fine_prenotazione = :endDate, cliente = :cliente, disponibile = :disp WHERE id = :id');
    
        /* con il metodo BINDPARAM associo il parametro al valore della variabile per inserirlo nella query*/
        $query->bindParam(':startDate', $_GET['startDate']);
        $query->bindParam(':endDate', $_GET['endDate']);
        $query->bindParam(':cliente', $_GET['cliente']);
        $query->bindParam(':disp', $_GET['disp']);
        $query->bindParam(':id', $_GET['id']);

        /* eseguo la query */
        $query->execute();
        
        /* chiudo il cursore e libero la memoria dalla connessione */
        $query->closeCursor();
        $connessione = null;
        
        echo("Prenotazione OK");
        
    }
    
    if ($source == "utente"){
        
        /* INSERT */
        $query = "INSERT INTO clienti (nome, cognome, cellulare, data_nascita) VALUE (:nome, :cognome, :cellulare, :data_nascita )";
        $userQuery = $connessione->prepare($query);
        /* con il metodo BINDPARAM associo il parametro al valore della variabile per inserirlo nella query*/
        $userQuery->bindParam(':nome', $_GET['nome']);
        $userQuery->bindParam(':cognome', $_GET['cognome']);
        $userQuery->bindParam(':cellulare', $_GET['cellulare']);
        $userQuery->bindParam(':data_nascita', $_GET['data_nascita']);
        
        /*eseguo la query*/
        $userQuery->execute();
        
        /* chiudo il cursore e libero la memoria dalla connessione */
        $userQuery->closeCursor();
        $connessione = null;
        
        echo("Utente OK");
        
    }
    
    if ($source == "prezzoMezGiorno") {
        
        $query = $connessione->prepare('UPDATE disp_uffici SET prezzoMezzoGiorno = :prezzo WHERE id = :id');
        
        /* con il metodo BINDPARAM associo il parametro al valore della variabile per inserirlo nella query*/
        $query->bindParam(':prezzo', $_GET['prezzo']);
        $query->bindParam(':id', $_GET['id']);
        
        /* eseguo la query */
        $query->execute();
        
        /* chiudo il cursore e libero la memoria dalla connessione */
        $query->closeCursor();
        $connessione = null;

        
    }
    
    if ($source == "prezzoGiorno") {
        
        $query = $connessione->prepare('UPDATE disp_uffici SET prezzoGiorno = :prezzo WHERE id = :id');
        
        /* con il metodo BINDPARAM associo il parametro al valore della variabile per inserirlo nella query*/
        $query->bindParam(':prezzo', $_GET['prezzo']);
        $query->bindParam(':id', $_GET['id']);
        
        /* eseguo la query */
        $query->execute();
        
        /* chiudo il cursore e libero la memoria dalla connessione */
        $query->closeCursor();
        $connessione = null;
        
        
    }
    
    if ($source == "prezzoMese") {
        
        $query = $connessione->prepare('UPDATE disp_uffici SET prezzoMese = :prezzo WHERE id = :id');
        
        /* con il metodo BINDPARAM associo il parametro al valore della variabile per inserirlo nella query*/
        $query->bindParam(':prezzo', $_GET['prezzo']);
        $query->bindParam(':id', $_GET['id']);
        
        /* eseguo la query */
        $query->execute();
        
        /* chiudo il cursore e libero la memoria dalla connessione */
        $query->closeCursor();
        $connessione = null;
        
        
    }
    
    if ($source == "accettazione") {
        
        $query = $connessione->prepare('UPDATE pren_future SET accettata = 1 WHERE stanza_prenotata = :stanza AND id_prenotazione = :id_pren');
        
        /* con il metodo BINDPARAM associo il parametro al valore della variabile per inserirlo nella query*/
        $query->bindParam(':stanza', $_GET['stanza']);
        $query->bindParam(':id_pren', $_GET['id_pren']);
        
        /* eseguo la query */
        $query->execute();
        
        /* chiudo il cursore e libero la memoria dalla connessione */
        $query->closeCursor();
        $connessione = null;
        
    }
    
    if ($source == "eliminazione") {
        
        $query = $connessione->prepare('DELETE FROM pren_future WHERE id_prenotazione = :id_pren');
        
        /* con il metodo BINDPARAM associo il parametro al valore della variabile per inserirlo nella query*/
        $query->bindParam(':id_pren', $_GET['id_pren']);
        
        /* eseguo la query */
        $query->execute();
        
        /* chiudo il cursore e libero la memoria dalla connessione */
        $query->closeCursor();
        $connessione = null;
        
    }

 ?>
