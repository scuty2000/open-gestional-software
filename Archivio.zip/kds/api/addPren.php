<?php

include('include/connessione.php');
    
$query = "INSERT INTO pren_future (stanza_prenotata, data_iniziale, data_finale, nome, cognome, email, cellulare, accettata) VALUE (:stanza, :dataStart, :dataEnd, :nome, :cognome, :email, :cellulare, 0 )";
$prenQuery = $connessione->prepare($query);
    
$prenQuery->bindParam(':nome', $_GET['nome']);
$prenQuery->bindParam(':email', $_GET['email']);
$prenQuery->bindParam(':stanza', $_GET['ufficio']);
$prenQuery->bindParam(':cognome', $_GET['cognome']);
$prenQuery->bindParam(':dataEnd', $_GET['dataEnd']);
$prenQuery->bindParam(':cellulare', $_GET['cellulare']);
$prenQuery->bindParam(':dataStart', $_GET['dataStart']);
    
$prenQuery->execute();
    
$prenQuery->closeCursor();
$connessione = null;
    
?>
