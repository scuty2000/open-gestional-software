<?php
    
    $mysqli = new mysqli('localhost', 'root', '', 'kds_ogs');
    if ($mysqli->connect_error) {
        die('Errore di connessione (' . $mysqli->connect_errno . ') '. $mysqli->connect_error);
    }
    
    //fetch table rows from mysql db
    $sql = "SELECT * FROM disp_uffici";
    $result = mysqli_query($mysqli, $sql) or die("Error in Selecting " . mysqli_error($connection));

    $myArray = array();
    while($row =mysqli_fetch_assoc($result))
    {
        array_push( $myArray , $row);
    }
    $data = json_encode($myArray);
    
    $fname = "fetch.json";
    $fcont = $data;
    
    echo($fcont);
    
    $fix_fcont = '{ "stored": '.$fcont.' }';
    $doc = fopen($fname, "w");
    fwrite($doc, $fix_fcont);
    fclose($doc);

?>

