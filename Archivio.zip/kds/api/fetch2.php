<?php
    
    $idStanza = $_GET['idStanza'];
    
    $mysqli = new mysqli('localhost', 'root', '', 'kds_ogs');
    if ($mysqli->connect_error) {
        die('Errore di connessione (' . $mysqli->connect_errno . ') '. $mysqli->connect_error);
    }
    
    $sql = "SELECT * FROM `pren_future` WHERE `stanza_prenotata` = ".$idStanza."";
    echo $sql;
    $result = mysqli_query($mysqli, $sql) or die("Error in Selecting " . mysqli_error($connection));

    $myArray = array();
    while($row =mysqli_fetch_assoc($result))
    {
        array_push( $myArray , $row);
    }
    $data = json_encode($myArray);
    
    $fname = "stanza".$idStanza.".json";
    $fcont = $data;
    
    echo($fcont);
    
    $fix_fcont = '{ "data": '.$fcont.' }';
    $doc = fopen($fname, "w");
    fwrite($doc, $fix_fcont);
    fclose($doc);

?>

