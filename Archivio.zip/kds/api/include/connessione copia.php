func checkFut8 () {
    
    myView14.mainFrame.load(URLRequest(url: URL(string: "http://127.0.0.1/kds/api/fetch2.php?idStanza=8")!))
    
    let dataFut8 = data_request(forData: "stanza8.json")
    _ = json_parseData(dataFut8!)
    
    if let json8 = json_parseData(dataFut8!) {
        let data_array8: NSArray = (json8["data"] as? NSArray)!
        
        var total8 = 0
        
        for _ in data_array8 {
            
            total8 = total8 + 1
            
        }
        
        if total8 == 0 {
            
            prenID8.stringValue = "-";
            nomeCognomeFutInfo8.stringValue = "Non ci sono prenotazioni";
            dataInizioFineFut8.stringValue = "-"
            contattiFut8.stringValue = "-"
            avanti8.isHidden = true
            accetta8.isHidden = true
            elimina8.isHidden = true
            indietro8.isHidden = true
            
        } else {
            
            if total8 == 1 {
                
                elimina8.isHidden = false
                
                let Stanza8Dic: NSDictionary = data_array8[0] as! NSDictionary
                
                prenID8.stringValue = (Stanza8Dic["id_prenotazione"] as? String!)!;
                let stringaCliente8 = "\(((Stanza8Dic["nome"] as? String!)!)!) \(((Stanza8Dic["cognome"] as? String!)!)!)"
                nomeCognomeFutInfo8.stringValue = stringaCliente8
                let dateFutu8 = "\(((Stanza8Dic["data_iniziale"] as? String!)!)!) - \(((Stanza8Dic["data_finale"] as? String!)!)!)"
                dataInizioFineFut8.stringValue = dateFutu8
                let contattiCliente8 = "\(((Stanza8Dic["email"] as? String!)!)!) ≈ \(((Stanza8Dic["cellulare"] as? String!)!)!)"
                contattiFut8.stringValue = contattiCliente8
                
                if(((Stanza8Dic["accettata"] as? String!)!)! == "0") {
                    
                    self.accetta8.isHidden = false
                    
                } else {
                    
                    self.accetta8.isHidden = true
                    
                }
                
                avanti8.isHidden = true
                indietro8.isHidden = true
                
            } else {
                
                if (total8 > (currentIndex8+1) && currentIndex8 != 0) {
                    
                    avanti8.isHidden = false
                    indietro8.isHidden = false
                    
                    elimina8.isHidden = false
                    
                    let Stanza8Dic: NSDictionary = data_array8[currentIndex8] as! NSDictionary
                    
                    prenID8.stringValue = (Stanza8Dic["id_prenotazione"] as? String!)!;
                    let stringaCliente8 = "\(((Stanza8Dic["nome"] as? String!)!)!) \(((Stanza8Dic["cognome"] as? String!)!)!)"
                    nomeCognomeFutInfo8.stringValue = stringaCliente8
                    let dateFutu8 = "\(((Stanza8Dic["data_iniziale"] as? String!)!)!) - \(((Stanza8Dic["data_finale"] as? String!)!)!)"
                    dataInizioFineFut8.stringValue = dateFutu8
                    let contattiCliente8 = "\(((Stanza8Dic["email"] as? String!)!)!) ≈ \(((Stanza8Dic["cellulare"] as? String!)!)!)"
                    contattiFut8.stringValue = contattiCliente8
                    
                    if(((Stanza8Dic["accettata"] as? String!)!)! == "0") {
                        
                        self.accetta8.isHidden = false
                        
                    } else {
                        
                        self.accetta8.isHidden = true
                        
                    }
                    
                    
                } else {
                    
                    if(currentIndex8 == 0) {
                        
                        avanti8.isHidden = false
                        indietro8.isHidden = true
                        
                        elimina8.isHidden = false
                        
                        let Stanza8Dic: NSDictionary = data_array8[currentIndex8] as! NSDictionary
                        
                        prenID8.stringValue = (Stanza8Dic["id_prenotazione"] as? String!)!;
                        let stringaCliente8 = "\(((Stanza8Dic["nome"] as? String!)!)!) \(((Stanza8Dic["cognome"] as? String!)!)!)"
                        nomeCognomeFutInfo8.stringValue = stringaCliente8
                        let dateFutu8 = "\(((Stanza8Dic["data_iniziale"] as? String!)!)!) - \(((Stanza8Dic["data_finale"] as? String!)!)!)"
                        dataInizioFineFut8.stringValue = dateFutu8
                        let contattiCliente8 = "\(((Stanza8Dic["email"] as? String!)!)!) ≈ \(((Stanza8Dic["cellulare"] as? String!)!)!)"
                        contattiFut8.stringValue = contattiCliente8
                        
                        if(((Stanza8Dic["accettata"] as? String!)!)! == "0") {
                            
                            self.accetta8.isHidden = false
                            
                        } else {
                            
                            self.accetta8.isHidden = true
                            
                        }
                        
                    } else {
                        
                        if (total8 == (currentIndex8+1)) {
                            
                            avanti8.isHidden = true
                            indietro8.isHidden = false
                            
                            elimina8.isHidden = false
                            
                            let Stanza8Dic: NSDictionary = data_array8[currentIndex8] as! NSDictionary
                            
                            prenID8.stringValue = (Stanza8Dic["id_prenotazione"] as? String!)!;
                            let stringaCliente8 = "\(((Stanza8Dic["nome"] as? String!)!)!) \(((Stanza8Dic["cognome"] as? String!)!)!)"
                            nomeCognomeFutInfo8.stringValue = stringaCliente8
                            let dateFutu8 = "\(((Stanza8Dic["data_iniziale"] as? String!)!)!) - \(((Stanza8Dic["data_finale"] as? String!)!)!)"
                            dataInizioFineFut8.stringValue = dateFutu8
                            let contattiCliente8 = "\(((Stanza8Dic["email"] as? String!)!)!) ≈ \(((Stanza8Dic["cellulare"] as? String!)!)!)"
                            contattiFut8.stringValue = contattiCliente8
                            
                            if(((Stanza8Dic["accettata"] as? String!)!)! == "0") {
                                
                                self.accetta8.isHidden = false
                                
                            } else {
                                
                                self.accetta8.isHidden = true
                                
                            }
                            
                            
                        }
                        
                    }
                    
                }
                
            }
            
        }
    }
    
    let when8 = DispatchTime.now() + 1
    DispatchQueue.main.asyncAfter(deadline: when8) {
        
        _ = self.checkFut8()
        
    }
    
}
